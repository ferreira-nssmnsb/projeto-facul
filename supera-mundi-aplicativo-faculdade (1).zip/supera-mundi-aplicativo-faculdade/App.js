import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, FlatList, TouchableOpacity, Image, KeyboardAvoidingView, Animated } from 'react-native';

export default function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [slideAnim] = useState(new Animated.Value(0));

  const validUsername = '276.946.451-56';
  const validPassword = '276.946.451-56';

  const handleLogin = () => {
    if (!username || !password) {
      setErrorMessage('Por favor, preencha ambos os campos.');
      return;
    }

    if (username === validUsername && password === validPassword) {
      setErrorMessage('');
      setIsLoggedIn(true);
    } else {
      setErrorMessage('Usuário ou senha incorretos.');
    }
  };

  const notas = [
    { id: '1', disciplina: 'Matemática', nota: 8.5 },
    { id: '2', disciplina: 'Português', nota: 7.0 },
    { id: '3', disciplina: 'História', nota: 9.2 },
    { id: '4', disciplina: 'Ciências', nota: 6.8 },
    { id: '5', disciplina: 'Geografia', nota: 8.0 },
  ];

  const frequencias = [
    { id: '1', disciplina: 'Matemática', presencas: 15, totalAulas: 20 },
    { id: '2', disciplina: 'Português', presencas: 18, totalAulas: 20 },
    { id: '3', disciplina: 'História', presencas: 19, totalAulas: 20 },
    { id: '4', disciplina: 'Ciências', presencas: 16, totalAulas: 20 },
    { id: '5', disciplina: 'Geografia', presencas: 17, totalAulas: 20 },
  ];

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  const toggleSettings = () => {
    setShowSettings(!showSettings);
    Animated.timing(slideAnim, {
      toValue: showSettings ? 0 : 1,
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  const containerStyle = isDarkMode ? styles.containerDark : styles.containerLight;

  const settingsHeight = slideAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 100],
  });

  if (!isLoggedIn) {
    return (
      <KeyboardAvoidingView style={containerStyle} behavior="padding">
        <Image
          source={{ uri: 'https://superamundi.com.br/wp-content/uploads/2023/09/logo-sem-fundo-e1695397249721.png' }}
          style={styles.logo}
          resizeMode="contain"
        />
        <Text style={styles.header}>Login</Text>

        <TextInput
          style={styles.input}
          placeholder="Usuário"
          value={username}
          onChangeText={setUsername}
        />

        <TextInput
          style={styles.input}
          placeholder="Senha"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        {errorMessage ? <Text style={styles.error}>{errorMessage}</Text> : null}

        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
          <Text style={styles.loginText}>Entrar</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    );
  }

  return (
    <View style={containerStyle}>
      <Text style={styles.header}>Notas do Aluno</Text>

      <Text style={styles.subHeader}>Notas</Text>
      <FlatList
        data={notas}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>{item.disciplina}</Text>
            <Text style={styles.tableCell}>{item.nota}</Text>
          </View>
        )}
      />

      <Text style={styles.subHeader}>Frequência</Text>
      <FlatList
        data={frequencias}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>{item.disciplina}</Text>
            <Text style={styles.tableCell}>
              {item.presencas} / {item.totalAulas}
            </Text>
          </View>
        )}
      />

      <TouchableOpacity style={styles.settingsButton} onPress={toggleSettings}>
        <Text style={styles.settingsText}>{showSettings ? 'Ocultar Configurações' : 'Mostrar Configurações'}</Text>
      </TouchableOpacity>

      <Animated.View style={[styles.settingsContainer, { height: settingsHeight }]}>
        {showSettings && (
          <View style={styles.settingsContent}>
            <Text style={styles.settingsText}>Configurações</Text>
            <TouchableOpacity style={styles.themeToggleButton} onPress={toggleTheme}>
              <Text style={styles.themeToggleText}>{isDarkMode ? 'Modo Claro' : 'Modo Escuro'}</Text>
            </TouchableOpacity>
          </View>
        )}
      </Animated.View>

      <TouchableOpacity style={styles.logoutButton} onPress={() => setIsLoggedIn(false)}>
        <Text style={styles.logoutText}>Sair</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  containerLight: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f0f4f8',
    paddingHorizontal: 20,
  },
  containerDark: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#2c3e50',
    paddingHorizontal: 20,
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 20,
    borderRadius: 75,
    overflow: 'hidden',
  },
  header: {
    fontSize: 36,
    marginBottom: 20,
    color: '#2c3e50',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subHeader: {
    fontSize: 28,
    marginVertical: 16,
    color: '#34495e',
    fontWeight: 'bold',
  },
  input: {
    width: '100%',
    padding: 14,
    borderColor: '#bdc3c7',
    borderWidth: 1,
    marginBottom: 12,
    borderRadius: 10,
    backgroundColor: 'white',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  error: {
    color: '#e74c3c',
    marginBottom: 12,
    textAlign: 'center',
  },
  loginButton: {
    backgroundColor: '#2980b9',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginTop: 10,
    width: '100%',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  loginText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    padding: 12,
    borderBottomWidth: 1,
    borderColor: '#ddd',
    backgroundColor: '#ffffff',
    marginBottom: 10,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
  },
  tableCell: {
    width: '45%',
    textAlign: 'center',
    fontSize: 16,
    color: '#34495e',
  },
  logoutButton: {
    marginTop: 20,
    backgroundColor: '#e74c3c',
    padding: 10,
    borderRadius: 5,
    width: '100%',
    alignItems: 'center',
  },
  logoutText: {
    color: 'white',
    fontWeight: 'bold',
  },
  settingsButton: {
    marginTop: 20,
    backgroundColor: '#3498db',
    padding: 10,
    borderRadius: 5,
    width: '100%',
    alignItems: 'center',
  },
  settingsText: {
    color: 'white',
    fontWeight: 'bold',
  },
  settingsContainer: {
    overflow: 'hidden',
    width: '100%',
    backgroundColor: '#ecf0f1',
    borderRadius: 8,
    elevation: 3,
  },
  settingsContent: {
    padding: 10,
  },
  themeToggleButton: {
    marginTop: 10,
    backgroundColor: '#f39c12',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  themeToggleText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

// ... (outros estilos)